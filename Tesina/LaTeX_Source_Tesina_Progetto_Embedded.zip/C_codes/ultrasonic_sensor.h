/* ------------------------------------------------------------------------------ */

typedef struct _ULTRASONIC_HandleTypeDef{
    ULTRASONIC_InitTypeDef 			 Init;
    TIM_HandleTypeDef* 	   	   	     htim;
    float 			   	   	    	 distance;
    float* 			   	   			 distance_history;
    uint32_t						 hist_idx;
    ULTRASONIC_IO_TypeDef 			 io;
    volatile ULTRASONIC_Flag_Typedef flag;
    uint8_t							 id;
}ULTRASONIC_HandleTypeDef;


ULTRASONIC_StatusTypeDef ULTRASONIC_Init(ULTRASONIC_HandleTypeDef*);
void                     ULTRASONIC_DeInit(void);

ULTRASONIC_StatusTypeDef ULTRASONIC_CaptureMeasure(ULTRASONIC_HandleTypeDef*);
void                     ULTRASONIC_Delay_us(ULTRASONIC_HandleTypeDef*, uint16_t);

void                     ULTRASONIC_IC_Callback(TIM_HandleTypeDef*);
void                     ULTRASONIC_Timeout_Callback(TIM_HandleTypeDef*);

/* ------------------------------------------------------------------------------ */
