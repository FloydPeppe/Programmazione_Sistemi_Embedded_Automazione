/* ------------------------------------------------------------------------------ */

typedef struct _SERVO_HandleTypeDef{
	SERVO_InitTypeDef  Init;
	TIM_HandleTypeDef* htim;
	uint32_t           pwm_channel;
	int                min_duty_beats;
	int                max_duty_beats;
}SERVO_HandleTypeDef;


void SERVO_Init(SERVO_HandleTypeDef*);
void SERVO_DeInit(SERVO_HandleTypeDef*);

void SERVO_SetBeats(SERVO_HandleTypeDef*, int);
void SERVO_SetDegree(SERVO_HandleTypeDef*, float);

/* ------------------------------------------------------------------------------ */