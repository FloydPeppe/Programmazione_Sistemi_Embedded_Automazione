// Declaring array of float' pointers
float *input[2];

// Assigning values
input[left ]= SMOOTH_INPUT_L;
input[right]= SMOOTH_INPUT_R;

// Move differential drive
DIFFDRIVE_InputArray(N_SAMPLE_ID, input);