/* ------------------------------------------------------------------------------ */

void DIFFDRIVE_Init(DIFFDRIVE_HandleTypeDef*);
void DIFFDRIVE_DeInit(void);

void DIFFDRIVE_MOTOR_SetPWMs(float*);
void DIFFDRIVE_MOTOR_Stop(void);

void                    DIFFDRIVE_ENCODER_Reset(void);
DIFFDRIVE_StatusTypeDef DIFFDRIVE_ENCODER_CaptureMeasure(void);

void DIFFDRIVE_CONTROL_Start(void);
void DIFFDRIVE_CONTROL_Stop(void);
void DIFFDRIVE_CONTROL_Reset(void);
void DIFFDRIVE_CONTROL_WheelStep(float*);

void DIFFDRIVE_TIMING_Start(void);
void DIFFDRIVE_TIMING_Stop(void);
void DIFFDRIVE_TIMING_Wait(void);
void DIFFDRIVE_TIMING_PeriodElapsedCallback(TIM_HandleTypeDef*);

void DIFFDRIVE_STATE_Update(float*);

void DIFFDRIVE_HISTORY_Start(void);
void DIFFDRIVE_HISTORY_Stop(void);
void DIFFDRIVE_HISTORY_Update(float, float);
void DIFFDRIVE_HISTORY_Get_Init(void);
void DIFFDRIVE_HISTORY_Get_Sample(DIFFDRIVE_STATE_TypeDef*,
                                  DIFFDRIVE_STATE_TypeDef*);

void DIFFDRIVE_DeltaWheel2DeltaTrajectory(float*, float*, float*);
void DIFFDRIVE_DeltaTrajectory2WheelAngle(float*, float, float);

void DIFFDRIVE_TrackingStart(void);
void DIFFDRIVE_TrackingStop(void);
void DIFFDRIVE_TrackingStep(float, float);
void DIFFDRIVE_TrackingArray(int, float*, float*);
void DIFFDRIVE_InputArray(int, float**);

/* ------------------------------------------------------------------------------ */