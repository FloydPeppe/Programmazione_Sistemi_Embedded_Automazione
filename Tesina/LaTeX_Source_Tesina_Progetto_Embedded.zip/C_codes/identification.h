/*
 * identification.h
 *
 *  Created on: 15-Feb-2022 19:37:48
 *
 */

#ifndef INC_IDENTIFICATION_DATA_H_
#define INC_IDENTIFICATION_DATA_H_

#define N_AR_L  3
#define N_MA_L  1
#define TAU_L   2

#define N_AR_R  3
#define N_MA_R  1
#define TAU_R   2

#define AR_L (float[N_AR_L]) { 1.0000000000, -1.9663645063, 0.9663645063 }
#define MA_L (float[N_MA_L]) { 0.0011516905 }

#define AR_R (float[N_AR_R]) { 1.0000000000, -1.9641343394, 0.9641343394 }
#define MA_R (float[N_MA_R]) { 0.0012107323 }

#endif /* INC_IDENTIFICATION_DATA_H_ */