/* ------------------------------------------------------------------------------ */

typedef struct _DATASTREAM_HandleTypeDef{
	DATASTREAM_InitTypeDef  Init;
	UART_HandleTypeDef*     huart;
	bool 			        DMA_Rx_Enable;
	int32_t                 DMA_Rx_Stream_IRQn;
	volatile bool           RxCpltFlag;
	uint8_t				    id;
}DATASTREAM_HandleTypeDef;
DATASTREAM_StatusTypeDef DATASTREAM_Init(DATASTREAM_HandleTypeDef*);
void                     DATASTREAM_DeInit(void);


DATASTREAM_StatusTypeDef DATASTREAM_ReceiveDMA(DATASTREAM_HandleTypeDef*, uint8_t*,
                                               uint32_t);
                                               
void DATASTREAM_Print(DATASTREAM_HandleTypeDef*, DATASTREAM_PrintMode, int, ...);

void DATASTREAM_RxCpltCallback(UART_HandleTypeDef*);
void DATASTREAM_ErrorCallback (UART_HandleTypeDef*);

/* ------------------------------------------------------------------------------ */