/*
 * diffdrive_parameters.h
 *
 *  Generated from MATLAB 
 *  17-Feb-2022 00:04:54
 *      
 */

#ifndef INC_MY_DATA_DIFFDRIVE_PARAMETERS_H_
#define INC_MY_DATA_DIFFDRIVE_PARAMETERS_H_


// Half the distance between wheels, in meters
#define WHEEL_DISTANCE 0.077500f

// Wheels radius in meters
#define WHEEL_RADIUS 0.034500f

// Radiant each seconds (rad/s)
#define WHEEL_MAX_SPEED 10.000000f

// Supply voltage 
#define SUPPLY_VOLTAGE 7.500000f

// Minimum voltage 
#define MOTOR_MIN_VOLTAGE 0.000000f

// Maximum voltage 
#define MOTOR_MAX_VOLTAGE 7.500000f

// Control law time step
#define TIME_STEP 0.010000f


#endif /* INC_MY_DATA_DIFFDRIVE_PARAMETERS_H_ */