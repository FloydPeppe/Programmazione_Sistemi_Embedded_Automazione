// Start control
DIFFDRIVE_TrackingStart();

// Tracking a target trajectory (Array of N sample)
DIFFDRIVE_TrackingArray(N_SAMPLE_REF, DELTA_A_REF, DELTA_THETA_REF);

// Stop differential drive
DIFFDRIVE_TrackingStop();