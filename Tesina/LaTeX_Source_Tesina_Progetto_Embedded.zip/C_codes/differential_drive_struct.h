/* ------------------------------------------------------------------------------ */

typedef struct _DIFFDRIVE_HandleTypeDef{
    DIFFDRIVE_InitTypeDef          Init;
    DIFFDRIVE_MOTOR_TypeDef        motor[2];
    DIFFDRIVE_ENCODER_TypeDef      encoder[2];
    DIFFDRIVE_CONTROL_TypeDef      control[2];    
    DIFFDRIVE_TIMING_TypeDef       timing;
    DIFFDRIVE_STATE_TypeDef        state;
    DIFFDRIVE_HISTORY_TypeDef      history;
    DIFFDRIVE_Mechanical_Parameter mech_prmtr;
}DIFFDRIVE_HandleTypeDef;

/* ------------------------------------------------------------------------------ */